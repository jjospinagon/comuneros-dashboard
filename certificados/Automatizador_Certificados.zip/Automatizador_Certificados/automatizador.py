# -*- coding: utf-8 -*-
"""
AUTOMATIZADOR DE CERTIFICADOS DE ANTECEDENTES — COLOMBIA
=========================================================
Flujo por persona y por portal:
  1. Abre el portal en Chrome (visible).
  2. Llena automáticamente cédula / fecha de expedición / NIT / razón social.
  3. PAUSA: usted resuelve el captcha y pulsa el botón de consulta del portal.
  4. Captura el certificado: si el portal descarga un PDF lo guarda y renombra;
     si solo muestra el resultado en pantalla, lo captura como PDF (pantallazo).
  5. Al terminar todos los portales, genera NOMBRE_CC<cedula>.zip

Requisitos (una sola vez): ejecutar INSTALAR.bat
Uso: ejecutar EJECUTAR.bat  (o: python automatizador.py)

Entrada de personal:
  - personas.csv  → cedula;fecha_expedicion(DD/MM/AAAA);nombre   (una por línea)
  - si no existe, pide los datos por consola (modo individual).
Configuración de empresa (NIT / razón social): config.ini
"""

import configparser
import csv
import os
import re
import sys
import time
import unicodedata
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

from playwright.sync_api import sync_playwright, Page, Frame, Download

BASE = Path(__file__).resolve().parent
SALIDA_BASE = BASE / "CERTIFICADOS"

# ----------------------------------------------------------------------------
# CATÁLOGO DE PORTALES
#   datos: campos que se intentan llenar automáticamente
#   captura: "descarga" (el portal entrega PDF) | "pantalla" (se captura la vista)
# ----------------------------------------------------------------------------
PORTALES = [
    {
        "id": "PROCURADURIA",
        "nombre": "Antecedentes Disciplinarios - Procuraduría",
        "url": "https://www.procuraduria.gov.co/pages/certificado-antecedentes.aspx",
        "datos": ["cedula"],
        "captura": "descarga",
    },
    {
        "id": "CONTRALORIA",
        "nombre": "Antecedentes Fiscales - Contraloría",
        "url": "https://www.contraloria.gov.co/web/guest/persona-natural",
        "datos": ["cedula"],
        "captura": "descarga",
    },
    {
        "id": "POLICIA_JUDICIALES",
        "nombre": "Antecedentes Judiciales - Policía Nacional",
        "url": "https://antecedentes.policia.gov.co:7005/WebJudicial/",
        "datos": ["cedula"],
        "captura": "pantalla",
    },
    {
        "id": "RNMC",
        "nombre": "Medidas Correctivas (RNMC) - Policía",
        "url": "https://srvcnpc.policia.gov.co/PSC/frm_cnp_consulta.aspx",
        "datos": ["cedula", "fecha"],
        "captura": "pantalla",
    },
    {
        "id": "REDAM",
        "nombre": "Deudores Alimentarios (REDAM)",
        "url": "https://redam.gov.co/",
        "datos": ["cedula"],
        "captura": "descarga",
    },
    {
        "id": "DELITOS_SEXUALES",
        "nombre": "Inhabilidades por Delitos Sexuales (Ley 1918/2018)",
        "url": "https://inhabilidades.policia.gov.co:8080/",
        "datos": ["cedula", "fecha", "nit", "razon"],
        "captura": "descarga",
    },
]

# Patrones (regex, sin tildes, minúsculas) para reconocer campos por
# name / id / placeholder / aria-label / label asociado.
PATRONES = {
    "cedula": r"(documento|cedula|identificac|nuip|nro.?doc|numero.?doc|txt.?doc|expediente)",
    "fecha":  r"(fecha.{0,12}exped|exped.{0,12}fecha|fec.?exp)",
    "nit":    r"\bnit\b",
    "razon":  r"(razon.?social|entidad|empresa|consultante)",
}
PATRON_SELECT_TIPODOC = r"(cedula\s+de\s+ciudadania|c\.?c\.?\b)"


@dataclass
class Persona:
    cedula: str
    fecha: str          # DD/MM/AAAA
    nombre: str
    descargas: list = field(default_factory=list)

    @property
    def carpeta(self) -> Path:
        return SALIDA_BASE / f"{slug(self.nombre)}_CC{self.cedula}"


# ----------------------------------------------------------------------------
# UTILIDADES
# ----------------------------------------------------------------------------
def slug(texto: str) -> str:
    t = unicodedata.normalize("NFD", texto.upper())
    t = "".join(c for c in t if unicodedata.category(c) != "Mn")
    t = re.sub(r"[^A-Z0-9 ]", "", t)
    return re.sub(r" +", "_", t.strip()) or "PERSONA"


def sin_tildes(texto: str) -> str:
    t = unicodedata.normalize("NFD", texto or "")
    return "".join(c for c in t if unicodedata.category(c) != "Mn").lower()


def leer_config() -> dict:
    cfg = configparser.ConfigParser()
    ruta = BASE / "config.ini"
    datos = {"nit": "", "razon": ""}
    if ruta.exists():
        cfg.read(ruta, encoding="utf-8")
        datos["nit"] = cfg.get("EMPRESA", "nit", fallback="").strip()
        datos["razon"] = cfg.get("EMPRESA", "razon_social", fallback="").strip()
    return datos


def leer_personas() -> list:
    """personas.csv → cedula;fecha;nombre. Si no existe, modo individual."""
    ruta = BASE / "personas.csv"
    personas = []
    if ruta.exists():
        with open(ruta, encoding="utf-8-sig") as f:
            for fila in csv.reader(f, delimiter=";"):
                fila = [c.strip() for c in fila if c.strip()]
                if len(fila) >= 3 and fila[0].lower() != "cedula":
                    personas.append(Persona(re.sub(r"\D", "", fila[0]), fila[1], fila[2].upper()))
    if not personas:
        print("\n--- MODO INDIVIDUAL (no se encontro personas.csv) ---")
        ced = re.sub(r"\D", "", input("Cedula: ").strip())
        fec = input("Fecha de expedicion (DD/MM/AAAA): ").strip()
        nom = input("Nombre completo: ").strip().upper()
        personas.append(Persona(ced, fec, nom))
    return personas


def seleccionar_portales() -> list:
    print("\nCERTIFICADOS DISPONIBLES:")
    for i, p in enumerate(PORTALES, 1):
        print(f"  {i}. {p['nombre']}")
    sel = input("\nNumeros a tramitar separados por coma (ENTER = todos): ").strip()
    if not sel:
        return PORTALES
    idx = {int(n) for n in re.findall(r"\d+", sel) if 1 <= int(n) <= len(PORTALES)}
    return [PORTALES[i - 1] for i in sorted(idx)]


# ----------------------------------------------------------------------------
# AUTOLLENADO HEURÍSTICO
# Recorre todos los frames de la página; identifica campos por atributos y
# etiquetas. Si el portal cambia su HTML, el script sigue sirviendo: usted
# completa a mano lo que falte y la captura/descarga sigue siendo automática.
# ----------------------------------------------------------------------------
def llenar_frame(frame: Frame, valores: dict) -> int:
    llenados = 0

    # 1) <select> de tipo de documento → opción "CÉDULA DE CIUDADANÍA"
    try:
        for sel in frame.query_selector_all("select"):
            for op in sel.query_selector_all("option"):
                if re.search(PATRON_SELECT_TIPODOC, sin_tildes(op.inner_text())):
                    sel.select_option(value=op.get_attribute("value"))
                    llenados += 1
                    break
    except Exception:
        pass

    # 2) inputs de texto / fecha
    try:
        inputs = frame.query_selector_all(
            "input[type=text], input[type=tel], input[type=number], "
            "input[type=date], input:not([type])"
        )
    except Exception:
        return llenados

    for inp in inputs:
        try:
            if not inp.is_visible() or inp.is_disabled():
                continue
            firma = sin_tildes(" ".join(filter(None, [
                inp.get_attribute("name"), inp.get_attribute("id"),
                inp.get_attribute("placeholder"), inp.get_attribute("aria-label"),
                inp.get_attribute("formcontrolname"),
            ])))
            # label asociado por for=id
            iid = inp.get_attribute("id")
            if iid:
                lab = frame.query_selector(f'label[for="{iid}"]')
                if lab:
                    firma += " " + sin_tildes(lab.inner_text())

            for campo, patron in PATRONES.items():
                if campo in valores and valores[campo] and re.search(patron, firma):
                    valor = valores[campo]
                    if campo == "fecha" and (inp.get_attribute("type") or "") == "date":
                        d, m, a = valor.split("/")
                        valor = f"{a}-{m}-{d}"   # input date exige ISO
                    inp.fill(valor)
                    llenados += 1
                    break
        except Exception:
            continue
    return llenados


def autollenar(page: Page, persona: Persona, portal: dict, empresa: dict) -> None:
    valores = {"cedula": persona.cedula, "fecha": persona.fecha,
               "nit": empresa["nit"], "razon": empresa["razon"]}
    valores = {k: v for k, v in valores.items() if k in portal["datos"]}
    total = 0
    for intento in range(3):                       # apps JS cargan tarde
        page.wait_for_timeout(1500)
        for frame in page.frames:
            total += llenar_frame(frame, valores)
        if total:
            break
    print(f"    Campos llenados automaticamente: {total}"
          if total else "    (No se detectaron campos aun; llene manualmente si es el caso)")


# ----------------------------------------------------------------------------
# CAPTURA DEL CERTIFICADO
# ----------------------------------------------------------------------------
def capturar_pantalla_pdf(page: Page, destino: Path) -> None:
    """Pantallazo de página completa → PDF (evidencia para expediente)."""
    from PIL import Image
    png = destino.with_suffix(".png")
    page.screenshot(path=str(png), full_page=True)
    Image.open(png).convert("RGB").save(destino, "PDF", resolution=100)
    png.unlink(missing_ok=True)


def tramitar_portal(context, portal: dict, persona: Persona, empresa: dict) -> None:
    print(f"\n>>> {portal['nombre']}")
    page = context.new_page()
    descargas_portal = []

    def al_descargar(d: Download):
        destino = persona.carpeta / f"{portal['id']}_{persona.cedula}.pdf"
        n = 2
        while destino.exists():
            destino = persona.carpeta / f"{portal['id']}_{persona.cedula}_{n}.pdf"
            n += 1
        d.save_as(str(destino))
        descargas_portal.append(destino)
        persona.descargas.append(destino)
        print(f"    [OK] Descargado: {destino.name}")

    page.on("download", al_descargar)

    try:
        page.goto(portal["url"], timeout=60000, wait_until="domcontentloaded")
    except Exception as e:
        print(f"    [!] No se pudo abrir el portal: {e}")
        page.close()
        return

    autollenar(page, persona, portal, empresa)

    print("    1) Resuelva el CAPTCHA y pulse el boton de consulta del portal.")
    print("    2) Cuando el certificado este descargado o visible en pantalla,")
    input("       vuelva aqui y presione ENTER para continuar... ")

    page.wait_for_timeout(1500)                    # despacha eventos de descarga pendientes

    if not descargas_portal:                       # no hubo PDF → capturar pantalla
        try:
            destino = persona.carpeta / f"{portal['id']}_{persona.cedula}.pdf"
            capturar_pantalla_pdf(page, destino)
            persona.descargas.append(destino)
            print(f"    [OK] Capturado como PDF: {destino.name}")
        except Exception as e:
            print(f"    [!] No se pudo capturar: {e}")

    page.close()


def comprimir(persona: Persona) -> Path:
    zip_path = SALIDA_BASE / f"{slug(persona.nombre)}_CC{persona.cedula}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for archivo in sorted(persona.carpeta.glob("*")):
            z.write(archivo, arcname=f"{persona.carpeta.name}/{archivo.name}")
    return zip_path


# ----------------------------------------------------------------------------
# PRINCIPAL
# ----------------------------------------------------------------------------
def main() -> None:
    print("=" * 64)
    print(" AUTOMATIZADOR DE CERTIFICADOS DE ANTECEDENTES - COLOMBIA")
    print("=" * 64)

    empresa = leer_config()
    personas = leer_personas()
    portales = seleccionar_portales()

    requiere_empresa = any(p["id"] == "DELITOS_SEXUALES" for p in portales)
    if requiere_empresa and not (empresa["nit"] and empresa["razon"]):
        print("\nDelitos sexuales requiere datos de la empresa consultante:")
        empresa["nit"] = empresa["nit"] or input("NIT (sin DV): ").strip()
        empresa["razon"] = empresa["razon"] or input("Razon social: ").strip().upper()

    print(f"\nPersonas: {len(personas)} | Certificados por persona: {len(portales)}")
    SALIDA_BASE.mkdir(exist_ok=True)

    with sync_playwright() as pw:
        navegador = pw.chromium.launch(headless=False,
                                       args=["--start-maximized"])
        context = navegador.new_context(accept_downloads=True, no_viewport=True)

        for i, persona in enumerate(personas, 1):
            print("\n" + "-" * 64)
            print(f" PERSONA {i}/{len(personas)}: {persona.nombre} - CC {persona.cedula}")
            print("-" * 64)
            persona.carpeta.mkdir(parents=True, exist_ok=True)

            for portal in portales:
                tramitar_portal(context, portal, persona, empresa)

            zip_path = comprimir(persona)
            print(f"\n [ZIP] Generado: {zip_path}")

        navegador.close()

    print("\nProceso terminado. Archivos en:", SALIDA_BASE)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nCancelado por el usuario.")
        sys.exit(1)
