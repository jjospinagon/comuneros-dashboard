@echo off
chcp 65001 >nul
title Instalador - Automatizador de Certificados
echo ============================================================
echo  INSTALACION (solo se ejecuta una vez por computador)
echo ============================================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python no esta instalado.
    echo Descarguelo de https://www.python.org/downloads/
    echo IMPORTANTE: marque la casilla "Add Python to PATH" al instalar.
    pause
    exit /b 1
)

echo Instalando dependencias...
python -m pip install --upgrade pip
python -m pip install playwright pillow
python -m playwright install chromium

echo.
echo ============================================================
echo  Instalacion completa. Ya puede usar EJECUTAR.bat
echo ============================================================
pause
