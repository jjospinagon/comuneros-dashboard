@echo off
chcp 65001 >nul
title Automatizador de Certificados de Antecedentes
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
python automatizador.py
pause
